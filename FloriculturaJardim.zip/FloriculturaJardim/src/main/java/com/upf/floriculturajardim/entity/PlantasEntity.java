/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.upf.floriculturajardim.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotNull;
import java.io.Serializable;
import java.math.BigDecimal;

/**
 *
 * @author 198848
 */
@Entity
public class PlantasEntity implements Serializable {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    @NotNull 
    private int id;
    
    @Column(name = "nome")
    @NotNull 
    private String nome;
    
    @Column(name = "especie")
    @NotNull
    private String especie;
    
    @Column(name = "cor")
    @NotNull
    private String cor;
    
    @Column(name = "folhagem")
    @NotNull
    private boolean folhagem;
    
    @Column(name = "flor")
    @NotNull
    private boolean flor;
    
    @Column(name = "valor_unitario")
    @NotNull
    private int valorUnitario;
    
    @Column(name = "qtd_estoque")
    @NotNull
    private int qtd_estoque;
    
    @Column(name = "tamanho")
    @NotNull
    private int tamanho;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEspecie() {
        return especie;
    }

    public void setEspecie(String especie) {
        this.especie = especie;
    }

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    public boolean isFolhagem() {
        return folhagem;
    }

    public void setFolhagem(boolean folhagem) {
        this.folhagem = folhagem;
    }

    public boolean isFlor() {
        return flor;
    }

    public void setFlor(boolean flor) {
        this.flor = flor;
    }

    public int getValorUnitario() {
        return valorUnitario;
    }

    public void setValorUnitario(int valorUnitario) {
        this.valorUnitario = valorUnitario;
    }

    public int getQtd_estoque() {
        return qtd_estoque;
    }

    public void setQtd_estoque(int qtd_estoque) {
        this.qtd_estoque = qtd_estoque;
    }

    public int getTamanho() {
        return tamanho;
    }

    public void setTamanho(int tamanho) {
        this.tamanho = tamanho;
    }
    
}
