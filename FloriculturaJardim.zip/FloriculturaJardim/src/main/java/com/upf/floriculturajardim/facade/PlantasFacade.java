package com.upf.floriculturajardim.facade;

import com.upf.FloriculturaJardim.facade.AbstractFacade;
import com.upf.floriculturajardim.entity.PlantasEntity;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;
import java.util.ArrayList;
import java.util.List;

@Stateless           
public class PlantasFacade extends AbstractFacade<PlantasEntity> {

    @PersistenceContext(unitName = "ProjetojfprimefacesPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public PlantasFacade() {
        super(PlantasEntity.class);
    }

    private List<PlantasEntity> entityList;

    public List<PlantasEntity> buscarTodos() {
        entityList = new ArrayList<>();
        try {
            Query query = getEntityManager().createQuery("SELECT p FROM PlantasEntity p order by p.nome");
            if (!query.getResultList().isEmpty()) {
                entityList = (List<PlantasEntity>) query.getResultList();
            }
        } catch (Exception e) {
            System.out.println("Erro: " + e);
        }
        return entityList;
    }

    public PlantasEntity buscarPorEspecie(String especie) {
        PlantasEntity pessoa = new PlantasEntity();
        try {
            Query query = getEntityManager()
                    .createQuery("SELECT p FROM PlantasEntity p WHERE p.especie = :especie");
            query.setParameter("especie", especie);

            if (!query.getResultList().isEmpty()) {
                pessoa = (PlantasEntity) query.getSingleResult();
            }
        } catch (Exception e) {
            System.out.println("Erro: " + e);
        }
        return pessoa;
    }
}
