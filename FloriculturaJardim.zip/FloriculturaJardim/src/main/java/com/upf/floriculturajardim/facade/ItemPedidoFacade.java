package com.upf.floriculturajardim.facade;

import com.upf.floriculturajardim.entity.ItemPedidoEntity;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;
import java.util.ArrayList;
import java.util.List;

@Stateless        
public class ItemPedidoFacade extends AbstractFacade<ItemPedidoEntity> {

    @PersistenceContext(unitName = "FloriculturaJardimPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public ItemPedidoFacade() {
        super(ItemPedidoEntity.class);
    }

    private List<ItemPedidoEntity> entityList;

    public List<ItemPedidoEntity> buscarTodos() {
        entityList = new ArrayList<>();
        try {
            Query query = getEntityManager().createQuery("SELECT it FROM ItemPedidoEntity it order by it.pedido");
            if (!query.getResultList().isEmpty()) {
                entityList = (List<ItemPedidoEntity>) query.getResultList();
            }
        } catch (Exception e) {
            System.out.println("Erro: " + e);
        }
        return entityList;
    }

    public ItemPedidoEntity buscarPorPedido(Integer pedido) {
        ItemPedidoEntity item = new ItemPedidoEntity();
        try {
            Query query = getEntityManager()
                    .createQuery("SELECT it FROM ItemPedidoEntity it WHERE it.pedido = :pedido");
            query.setParameter("pedido", pedido);

            if (!query.getResultList().isEmpty()) {
                item = (ItemPedidoEntity) query.getSingleResult();
            }
        } catch (Exception e) {
            System.out.println("Erro: " + e);
        }
        return item;
    }
}
