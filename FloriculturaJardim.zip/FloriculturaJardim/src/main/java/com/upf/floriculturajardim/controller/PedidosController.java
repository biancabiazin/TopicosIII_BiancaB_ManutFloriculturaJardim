/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSF/JSFManagedBean.java to edit this template
 */
package com.upf.floriculturajardim.controller;

import com.upf.floriculturajardim.entity.PedidosEntity;
import jakarta.ejb.EJB;
import jakarta.ejb.EJBException;
import jakarta.inject.Named;
import jakarta.enterprise.context.SessionScoped;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author 198848
 */
@Named(value = "pedidosController")
@SessionScoped
public class PedidosController implements Serializable {

    @EJB
    private com.upf.floriculturajardim.facade.PedidosFacade ejbFacade;

    public PedidosController() {
    }

    private PedidosEntity selected;

    public PedidosEntity getSelected() {
        return selected;
    }

    public void setSelected(PedidosEntity selected) {
        this.selected = selected;
    }

    private PedidosEntity pedidos = new PedidosEntity();

    private List<PedidosEntity> pedidosList = new ArrayList<>();

    public PedidosEntity getPedidos() {
        return pedidos;
    }

    public void setPedidos(PedidosEntity pedidos) {
        this.pedidos = pedidos;
    }

    public List<PedidosEntity> getPedidosList() {
        return pedidosList;
    }

    public void setPedidosList(List<PedidosEntity> itemList) {
        this.pedidosList = pedidosList;
    }

    public PedidosEntity prepareAdicionar() {
        pedidos = new PedidosEntity();
        return pedidos;
    }

    public void adicionarPedidos() {
        persist(PedidosController.PersistAction.CREATE,
                "Registro incluído com sucesso!");
    }

    public void editarPedidos() {
        persist(PedidosController.PersistAction.UPDATE,
                "Registro alterado com sucesso!");
    }

    public void deletarPedidos() {
        persist(PedidosController.PersistAction.DELETE,
                "Registro excluído com sucesso!");
    }

    public static void addErrorMessage(String msg) {
        FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, msg, msg);
        FacesContext.getCurrentInstance().addMessage(null, facesMsg);
    }

    public static void addSuccessMessage(String msg) {
        FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_INFO, msg, msg);
        FacesContext.getCurrentInstance().addMessage("successInfo", facesMsg);
    }

    public static enum PersistAction {
        CREATE,
        DELETE,
        UPDATE
    }

    private void persist(PersistAction persistAction, String successMessage) {
        try {
            if (null != persistAction) {
                switch (persistAction) {
                    case CREATE:
                        ejbFacade.createReturn(pedidos);
                        break;
                    case UPDATE:
                        ejbFacade.edit(selected);
                        selected = null;
                        break;
                    case DELETE:
                        ejbFacade.remove(selected);
                        selected = null;
                        break;
                    default:
                        break;
                }
            }
            addSuccessMessage(successMessage);
        } catch (EJBException ex) {
            String msg = "";
            Throwable cause = ex.getCause();
            if (cause != null) {
                msg = cause.getLocalizedMessage();
            }
            if (msg.length() > 0) {
                addErrorMessage(msg);
            } else {
                addErrorMessage(ex.getLocalizedMessage());
            }
        } catch (Exception ex) {
            addErrorMessage(ex.getLocalizedMessage());
        }
    }
    
}
