package com.upf.floriculturajardim.controller;

import com.upf.floriculturajardim.entity.UsuarioEntity;
import com.upf.floriculturajardim.facade.UsuarioFacade;
import jakarta.annotation.PostConstruct;
import jakarta.ejb.EJB;
import jakarta.enterprise.context.SessionScoped;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import jakarta.inject.Named;
import jakarta.servlet.http.HttpSession;
import java.io.Serializable;

/**
 *
 * @author 198848
 */
@Named(value = "loginController")
@SessionScoped
public class LoginController implements Serializable {

    @EJB
    private UsuarioFacade usuarioFacade;

    private UsuarioEntity usuario;

    public LoginController() {
    }

    @PostConstruct
    public void init() {
        usuario = new UsuarioEntity();
    }

    public String validarLogin() {
        FacesContext context = FacesContext.getCurrentInstance();
        HttpSession session = (HttpSession) context.getExternalContext().getSession(false);

        UsuarioEntity usuarioDB = usuarioFacade.buscarPorCodigo(usuario.getCodigo(), usuario.getSenha());
        if (usuarioDB != null && usuarioDB.getId() != null) {
            session.setAttribute("usuarioLogado", usuarioDB);

            return "/admin/home.xhtml?faces-redirect=true";
        } else {
            FacesMessage fm = new FacesMessage(
                FacesMessage.SEVERITY_ERROR,
                "Falha no Login!",
                "Codigo ou senha incorretos!");
            FacesContext.getCurrentInstance().addMessage(null, fm);
            return null;
        }
    }

    public String logout() {
        FacesContext context = FacesContext.getCurrentInstance();
        HttpSession session = (HttpSession) context.getExternalContext().getSession(false);
        session.invalidate();
        return "/login.xhtml?faces-redirect=true";
    }

    public UsuarioEntity getUsuario() {
        return usuario;
    }

    public void setUsuario(UsuarioEntity usuario) {
        this.usuario = usuario;
    }
}
