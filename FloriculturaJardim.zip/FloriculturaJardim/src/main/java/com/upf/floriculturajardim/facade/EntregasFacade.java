package com.upf.floriculturajardim.facade;

import com.upf.FloriculturaJardim.facade.AbstractFacade;
import com.upf.floriculturajardim.entity.EntregasEntity;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;
import java.util.ArrayList;
import java.util.List;

@Stateless          
public class EntregasFacade extends AbstractFacade<EntregasEntity> {

    @PersistenceContext(unitName = "ProjetojfprimefacesPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public EntregasFacade() {
        super(EntregasEntity.class);
    }

    private List<EntregasEntity> entityList;

    public List<EntregasEntity> buscarTodos() {
        entityList = new ArrayList<>();
        try {
            Query query = getEntityManager().createQuery("SELECT e FROM EntregasEntity e order by e.seq");
            if (!query.getResultList().isEmpty()) {
                entityList = (List<EntregasEntity>) query.getResultList();
            }
        } catch (Exception e) {
            System.out.println("Erro: " + e);
        }
        return entityList;
    }

    public EntregasEntity buscarPorPedido(String pedido) {
        EntregasEntity entrega = new EntregasEntity();
        try {
            Query query = getEntityManager()
                    .createQuery("SELECT e FROM EntregasEntity e WHERE e.pedido = :pedido");
            query.setParameter("pedido", pedido);

            if (!query.getResultList().isEmpty()) {
                entrega = (EntregasEntity) query.getSingleResult();
            }
        } catch (Exception e) {
            System.out.println("Erro: " + e);
        }
        return entrega;
    }
}
