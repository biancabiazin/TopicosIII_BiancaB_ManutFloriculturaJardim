package com.upf.floriculturajardim.facade;

import com.upf.FloriculturaJardim.facade.AbstractFacade;
import com.upf.floriculturajardim.entity.UsuarioEntity;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;
import java.util.ArrayList;
import java.util.List;

@Stateless          
public class UsuarioFacade extends AbstractFacade<UsuarioEntity> {

    @PersistenceContext(unitName = "ProjetojfprimefacesPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public UsuarioFacade() {
        super(UsuarioEntity.class);
    }

    private List<UsuarioEntity> entityList;

    public List<UsuarioEntity> buscarTodos() {
        entityList = new ArrayList<>();
        try {
            Query query = getEntityManager().createQuery("SELECT u FROM UsuarioEntity u order by u.nome");
            if (!query.getResultList().isEmpty()) {
                entityList = (List<UsuarioEntity>) query.getResultList();
            }
        } catch (Exception e) {
            System.out.println("Erro: " + e);
        }
        return entityList;
    }

    public UsuarioEntity buscarPorCodigo(String codigo, String senha) {
        UsuarioEntity usuario = new UsuarioEntity();
        try {
            Query query = getEntityManager()
                    .createQuery("SELECT u FROM UsuarioEntity u WHERE u.codigo = :codigo AND u.senha = :senha");
            query.setParameter("codigo", codigo);
            query.setParameter("senha", senha);

            if (!query.getResultList().isEmpty()) {
                usuario = (UsuarioEntity) query.getSingleResult();
            }
        } catch (Exception e) {
            System.out.println("Erro: " + e);
        }
        return usuario;
    }
}
