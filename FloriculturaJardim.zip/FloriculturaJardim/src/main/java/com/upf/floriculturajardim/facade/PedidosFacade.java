package com.upf.floriculturajardim.facade;

import com.upf.floriculturajardim.entity.PedidosEntity;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Stateless         
public class PedidosFacade extends AbstractFacade<PedidosEntity> {

    @PersistenceContext(unitName = "FloriculturaJardimPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public PedidosFacade() {
        super(PedidosEntity.class);
    }

    private List<PedidosEntity> entityList;

    public List<PedidosEntity> buscarTodos() {
        entityList = new ArrayList<>();
        try {
            Query query = getEntityManager().
                    createQuery("SELECT p FROM PedidosEntity p ORDER BY p.id");
            entityList = (List<PedidosEntity>) query.getResultList();
        } catch (Exception e) {
            System.out.println("Erro: " + e);
        }
        return entityList;
    }
    
    public PedidosEntity buscarPorStatus(String status) {
        PedidosEntity item = new PedidosEntity();
        try {
            Query query = getEntityManager()
                    .createQuery("SELECT p FROM PedidosEntity p WHERE p.status = :status");
            query.setParameter("status", status);

            if (!query.getResultList().isEmpty()) {
                item = (PedidosEntity) query.getSingleResult();
            }
        } catch (Exception e) {
            System.out.println("Erro: " + e);
        }
        return item;
    }
    
    public PedidosEntity buscarPorData(Date data_pedido) {
        PedidosEntity item = new PedidosEntity();
        try {
            Query query = getEntityManager()
                    .createQuery("SELECT p FROM PedidosEntity p WHERE p.data_pedido = :data_pedido");
            query.setParameter("data_pedido", data_pedido);

            if (!query.getResultList().isEmpty()) {
                item = (PedidosEntity) query.getSingleResult();
            }
        } catch (Exception e) {
            System.out.println("Erro: " + e);
        }
        return item;
    }
    
    public PedidosEntity buscarPorEndereco(String endereco) {
        PedidosEntity item = new PedidosEntity();
        try {
            Query query = getEntityManager()
                    .createQuery("SELECT p FROM PedidosEntity p WHERE p.endereco = :endereco");
            query.setParameter("endereco", endereco);

            if (!query.getResultList().isEmpty()) {
                item = (PedidosEntity) query.getSingleResult();
            }
        } catch (Exception e) {
            System.out.println("Erro: " + e);
        }
        return item;
    }
    
}
