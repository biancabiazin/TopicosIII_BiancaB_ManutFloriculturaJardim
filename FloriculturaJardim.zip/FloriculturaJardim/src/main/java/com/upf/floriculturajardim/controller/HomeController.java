/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSF/JSFManagedBean.java to edit this template
 */
package com.upf.floriculturajardim.controller;

import com.upf.FloriculturaJardim.entity.HomeEntity;
import jakarta.inject.Named;
import jakarta.enterprise.context.SessionScoped;
import java.io.Serializable;

/**
 *
 * @author 198848
 */
@Named(value = "homeController")
@SessionScoped
public class HomeController implements Serializable {

    public HomeController() {
    }
    
    HomeEntity entity = new HomeEntity();
    
    public HomeEntity getEntity() {
        return entity;
    }
    
    public String irParaPlantas() {
        System.out.println("pag de plantas");
        return "/admin/plantas.xhtml?faces-redirect=true";
    }

    public String irParaClientes() {
        System.out.println("pag de clientes");
        return "/admin/clientes.xhtml?faces-redirect=true";
    }
    
    public String irParaPedidos() {
        System.out.println("pag de pedidos");
        return "/admin/pedidos.xhtml?faces-redirect=true";
    }
    
    public String irParaItens() {
        System.out.println("pag de itens");
        return "/admin/itensPedido.xhtml?faces-redirect=true";
    }
    
    public String irParaEntregas() {
        System.out.println("pag de entregas");
        return "/admin/entregas.xhtml?faces-redirect=true";
    }
    
    public String irParaUsuarios() {
        System.out.println("pag de usuarios");
        return "/admin/cadastroUsuario.xhtml?faces-redirect=true";
    }
    
}
