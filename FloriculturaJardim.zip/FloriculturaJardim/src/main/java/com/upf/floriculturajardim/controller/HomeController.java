package com.upf.floriculturajardim.controller;

import jakarta.inject.Named;
import jakarta.enterprise.context.SessionScoped;
import java.io.Serializable;

/**
 *
 * @author 198848
 */
@Named("homeController")
@SessionScoped
public class HomeController implements Serializable {

    public HomeController() {}

    public String irParaHome() {
        System.out.println("pag da home");
        return "/admin/home.xhtml?faces-redirect=true";
    }
    
    public String irParaPlantas() {
        System.out.println("pag de plantas");
        return "/admin/plantas.xhtml?faces-redirect=true";
    }

    public String irParaClientes() {
        System.out.println("pag de clientes");
        return "/admin/clientes.xhtml?faces-redirect=true";
    }

    public String irParaPedidos() {
        System.out.println("pag de pedidos");
        return "/admin/pedidos.xhtml?faces-redirect=true";
    }

    public String irParaItens() {
        System.out.println("pag de itens");
        return "/admin/itensPedido.xhtml?faces-redirect=true";
    }

    public String irParaEntregas() {
        System.out.println("pag de entregas");
        return "/admin/entregas.xhtml?faces-redirect=true";
    }

    public String irParaUsuarios() {
        System.out.println("pag de usuarios");
        return "/admin/cadastroUsuario.xhtml?faces-redirect=true";
    }
}
