/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSF/JSFManagedBean.java to edit this template
 */
package com.upf.floriculturajardim.controller;

import com.upf.floriculturajardim.entity.ItemPedidoEntity;
import jakarta.ejb.EJB;
import jakarta.ejb.EJBException;
import jakarta.inject.Named;
import jakarta.enterprise.context.SessionScoped;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author 198848
 */
@Named(value = "itemPedidoController")
@SessionScoped
public class ItemPedidoController implements Serializable {

    @EJB
    private com.upf.floriculturajardim.facade.ItemPedidoFacade ejbFacade;

    public ItemPedidoController() {
    }

    private ItemPedidoEntity selected;

    public ItemPedidoEntity getSelected() {
        return selected;
    }

    public void setSelected(ItemPedidoEntity selected) {
        this.selected = selected;
    }

    private ItemPedidoEntity item = new ItemPedidoEntity();

    private List<ItemPedidoEntity> itemList = new ArrayList<>();

    public ItemPedidoEntity getItem() {
        return item;
    }

    public void setItem(ItemPedidoEntity item) {
        this.item = item;
    }

    public List<ItemPedidoEntity> getItemList() {
        return itemList;
    }

    public void setItemList(List<ItemPedidoEntity> itemList) {
        this.itemList = itemList;
    }

    public ItemPedidoEntity prepareAdicionar() {
        item = new ItemPedidoEntity();
        return item;
    }

    public void adicionarItem() {
        persist(ItemPedidoController.PersistAction.CREATE,
                "Registro incluído com sucesso!");
    }

    public void editarItem() {
        persist(ItemPedidoController.PersistAction.UPDATE,
                "Registro alterado com sucesso!");
    }

    public void deletarItem() {
        persist(ItemPedidoController.PersistAction.DELETE,
                "Registro excluído com sucesso!");
    }

    public static void addErrorMessage(String msg) {
        FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, msg, msg);
        FacesContext.getCurrentInstance().addMessage(null, facesMsg);
    }

    public static void addSuccessMessage(String msg) {
        FacesMessage facesMsg = new FacesMessage(FacesMessage.SEVERITY_INFO, msg, msg);
        FacesContext.getCurrentInstance().addMessage("successInfo", facesMsg);
    }

    public static enum PersistAction {
        CREATE,
        DELETE,
        UPDATE
    }

    private void persist(PersistAction persistAction, String successMessage) {
        try {
            if (null != persistAction) {
                switch (persistAction) {
                    case CREATE:
                        ejbFacade.createReturn(item);
                        break;
                    case UPDATE:
                        ejbFacade.edit(selected);
                        selected = null;
                        break;
                    case DELETE:
                        ejbFacade.remove(selected);
                        selected = null;
                        break;
                    default:
                        break;
                }
            }
            addSuccessMessage(successMessage);
        } catch (EJBException ex) {
            String msg = "";
            Throwable cause = ex.getCause();
            if (cause != null) {
                msg = cause.getLocalizedMessage();
            }
            if (msg.length() > 0) {
                addErrorMessage(msg);
            } else {
                addErrorMessage(ex.getLocalizedMessage());
            }
        } catch (Exception ex) {
            addErrorMessage(ex.getLocalizedMessage());
        }
    }
    
}
