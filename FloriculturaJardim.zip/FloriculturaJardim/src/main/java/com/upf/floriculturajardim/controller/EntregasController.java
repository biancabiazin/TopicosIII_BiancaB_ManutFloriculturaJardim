package com.upf.floriculturajardim.controller;

import com.upf.floriculturajardim.entity.EntregasEntity;
import com.upf.floriculturajardim.facade.EntregasFacade;
import jakarta.inject.Named;
import jakarta.enterprise.context.SessionScoped;
import jakarta.inject.Inject;
import java.io.Serializable;
import java.util.List;

@Named(value = "entregasController")
@SessionScoped
public class EntregasController implements Serializable {

    private EntregasEntity entrega = new EntregasEntity();

    @Inject
    private EntregasFacade entregasFacade;

    public EntregasController() {
    }

    public EntregasEntity getEntrega() {
        return entrega;
    }

    public void setEntrega(EntregasEntity entrega) {
        this.entrega = entrega;
    }

    public List<EntregasEntity> getListaEntregas() {
        return entregasFacade.buscarTodos();
    }

    public void salvar() {
        try {
            if (entrega.getSeq() == 0) {
                entregasFacade.create(entrega);
            } else {
                entregasFacade.edit(entrega);
            }
            entrega = new EntregasEntity();
        } catch (Exception e) {
            System.out.println("Erro ao salvar entrega: " + e);
        }
    }

    public void excluir(EntregasEntity ent) {
        try {
            entregasFacade.remove(ent);
        } catch (Exception e) {
            System.out.println("Erro ao excluir entrega: " + e);
        }
    }

    public void editar(EntregasEntity ent) {
        this.entrega = ent;
    }

    public void limpar() {
        entrega = new EntregasEntity();
    }
}
